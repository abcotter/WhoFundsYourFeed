db_endpoint = 'whofundsyourfeed.ccybu7nlixr7.us-east-1.rds.amazonaws.com'
db_username = 'admin'
db_password = 'MSCIgals2022'
db_name = 'who_funds_your_feed'